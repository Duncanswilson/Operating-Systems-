/*
 * C Program to Implement Queue Data Structure using Linked List
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

////////////////////// DATA STRUCTURES /////////////////////////////////////////////////
/*task structure: 
  wraps all of the salient information for a given task in the meta-data file
  It is used as the data in the dynamic queue defined below
*/
typedef struct{
// char task identifier
    char* taskID; 
// task specifier   
    char* taskSpec;
// int number of cycles
    int cycleNum; 
}tasks; 

/* Config structure:
   wraps all of the important information from the config file 
*/
typedef struct {
    //processor cycle time
    int processorCT; 
    //montior cycle time
    int monitorCT; 
    //hdd cycle time
    int hddCT; 
    //print cycle time
    int printCT;  
    //keyboard cycle time
    int keyboardCT; 
    //log method 
    char logMethod;
    //log file path 
    char filePath[75];  
    //meta-data path 
    char metaPath[75];
    //scheduling type 
    char sched[25];
    //quantum time
    int quantum;
}config; 
 

/* task-node structure: 
    the data stored in the queue, used to bundle the pointer and task data */
typedef struct taskNode{
    tasks task;
    struct taskNode *ptr;
}taskNode; 

/* task Queue structure: 
   the data structure used for storing the tasks from the meta-data file */
typedef struct{
  taskNode *front; 
  taskNode *rear; 
}taskStack;

/*PCB structure: 
   Used to store:   the current state of the process
                    the processID (aka the priority)
                    the queue of tasks the process is to run
*/
typedef struct{
    char *processState; 
    int processID; 
    int priority; 
    taskStack taskS; 
}PCB;

/* PCB node structure: 
    the PCB data stored in the process queue, used to bundle the pointer and process data 
*/
typedef struct PCBnode {
    PCB process;
    struct PCBnode *ptr;
}PCBnode; 

/* Process Queue structure: 
    the data structure used for storing the processes from the meta-data file 
    this is a priority queue that orders the PCB's from least to greatest (on their processID)
    If two processIDs equal then put the newer entry behind the matching process
    A worthwhile note: *I removed the rear pointer when dealing with priority,
                        it just caused more headache since I can use the NULL
                        to tell if I'm at the end of queue *  
*/
typedef struct{
  PCBnode *front; 
}processQueue;

/* thread structure: 
    this data structure holds all of the information needed to be passed into the thread function 
    it was created purely because the p_thread_create function will only allow one parameter 
*/ 
typedef struct{
    PCB currentProcess; 
    tasks currentTask; 
    config cycles; 
    float currentTime;
    int* interruptPtr; 
}threadStruct;


////////////////////// Suppoting Functions for Data Structures /////////////////////////////////////////////////
//
/////////////////////////////////// Processs Queue Functions Headers////////////////////////////////////////////
void createProcess(processQueue*);
void enqProcess(processQueue*, PCB*);
PCB deqProcess(processQueue*);
int emptyProcess(processQueue*);
PCB removeProcess(processQueue *Q, int PID);
void displayP(processQueue* Q);
//
/////////////////////////////////////// Task Queue Functions Headers//////////////////////////////////////////////
void createTask(taskStack*);
void enqTask(taskStack*, tasks*);
tasks deqTask(taskStack*);
void pushTask(taskStack*, tasks*);
tasks popTask(taskStack*);
int emptyTask(taskStack*);
void displayT(taskStack* Q);
//
/////////////////////////////////// Processs Queue Functions Implementation///////////////////////////////////////
//
/* create()- takes a queue as a parmater and "creates" an empty queue */
void createProcess(processQueue *Q){
    Q->front = NULL;
}
 
/*enq() -  it inserts the PCB data into the process queue in order by processID 
            this creates a priortiy queue where if two processIDs equal 
            the newest PCB is stored behind the already existing entry  
*/
void enqProcess(processQueue *Q, PCB *data){
    //variable allocation and decleration 
    PCBnode *temp = (PCBnode*)malloc(1*sizeof(PCBnode));
    temp->process = *data;
    PCBnode *previous = NULL;
    PCBnode *current = Q->front; 

    //get to the right place to inset the process into queue off of priority 
    while(current != NULL && temp->process.priority >= current->process.priority){
        previous = current;
        current = current->ptr;
    }
    // if empty then load it 
    if(previous == NULL && current == NULL){
        temp->ptr = NULL; 
        Q->front = temp; 
    }
    // if highest priority then load it
    else if(previous == NULL){ 
        temp->ptr = Q->front;
        Q->front = temp; 
    }
    //if loading in the middle or at the back 
    else{
        previous->ptr = temp;
        temp->ptr = current;
    }
}
 
/*deq()-  removes and returns the first element from the queue */
PCB deqProcess(processQueue* Q){
    PCBnode *front1 = Q->front;
    PCB  returnProcess; 
    // if empty do nothing 
    if (front1 == NULL){
        printf("\n Error: Trying to dequeue elements from empty queue");
        return returnProcess;
    }
   //if not empty, remove first item 
    else
        if (front1->ptr != NULL){
            returnProcess = Q->front->process; 
            front1 = front1->ptr;
            free(Q->front);
            Q->front = front1;
            return returnProcess;
        }
        else{
            returnProcess = Q->front->process; 
            free(Q->front);
            Q->front = NULL;
            return returnProcess;
        }
}
 

/* empty()-  shows if queue is empty or not */
int emptyProcess(processQueue* Q){
     if (Q->front == NULL)
        return 0; 
    else
       return 1; 
}

/*remove() -  removes a process from the process with the address of target
              and then returns that PCB 
*/
PCB removeProcess(processQueue *Q, int PID){
    PCBnode *previous = NULL; 
    PCBnode *current = previous = Q->front;
    PCB returnProcess; 
//    printf("This is the current process' ID: %d and the parameter PID: %d\n",current->process.processID, PID);
    while(current->process.processID != PID ){
        previous = current; 
        current = current->ptr; 
//        printf("This is the current process' ID: %d and the parameter PID: %d\n",current->process.processID, PID);
    }
    returnProcess = current->process;
    if(current == Q->front){ 
        Q->front = Q->front->ptr; 
    }
    else{
    previous->ptr = current->ptr;
    } 
    free(current);
//    printf("This is the queue at the end of my remove process function\n"); 
//    displayP(Q);
//    printf("\n"); 
    return returnProcess;
}


/*display() -  takes in the queue as a parameter and then displays the queue elements */
void displayP(processQueue* Q){
   PCBnode* current = Q->front;

    if(current == NULL){
        printf("Process Queue is empty\n");
        return;
    } 
     printf("\nProcess ID:  %i \n", current->process.processID);
     printf("Task Queue: \n");
//     displayT(&current->process.taskS);
    while (current->ptr != NULL){
        current = current->ptr;
        printf("\nProcess ID:  %i \n", current->process.processID);
        printf("Task Queue: \n");
        displayT(&current->process.taskS);
    }
}

/////////////////////////////////// Task Queue Functions Implementation///////////////////////////////////////

/* create()- takes a stack as a parmater and "creates" an empty stack */
void createTask(taskStack *stack){
    stack->front = stack->rear = NULL;
}

/*enq() -  takes the queue and task data as paramters then adds the task at the rear of the queue */
void enqTask(taskStack *Q, tasks *data)
{
    taskNode *temp; 
    if (Q->rear == NULL)
    {
        //printf("Enqueue data: %s, %s, %i \n", data->taskID, data->taskSpec, data->cycleNum);
        Q->rear = (taskNode*)malloc(1*sizeof(taskNode));
        Q->rear->ptr = NULL;
        Q->rear->task = *data;
        Q->front = Q->rear;
    }
    else
    {
        //printf("Enqueue data: %s, %s, %i \n", data->taskID, data->taskSpec, data->cycleNum);
        temp = (taskNode*)malloc(1*sizeof(taskNode));
        Q->rear->ptr = temp;
        temp->task = *data;
        temp->ptr = NULL;
        Q->rear = temp;
    }
}
 
/*deq()-  removes and returns the first element from the queue */
tasks deqTask(taskStack* Q)
{
    taskNode *front1 = Q->front;
    tasks returnTask; 
    if (front1 == NULL)
    {
        printf("\n Error: Trying to dequeue elements from empty queue");
        return returnTask;
    }
    else
        if (front1->ptr != NULL)
        {
            returnTask = Q->front->task; 
            front1 = front1->ptr;
            free(Q->front);
            Q->front = front1;
            return returnTask;
        }
        else
        {
            returnTask = Q->front->task; 
            free(Q->front);
            Q->front = NULL;
            Q->rear = NULL;
            return returnTask;
        }
}
 
/*pushTask() -  takes the stack and task data as paramters then adds the task at the top of the stack */
void pushTask(taskStack *stack, tasks *data){
    taskNode *temp; 
    if (stack->front == NULL){
        stack->front = (taskNode*)malloc(1*sizeof(taskNode));
        stack->front->ptr = NULL;
        stack->front->task = *data;
        stack->rear = stack->front;
    }
    else{
        temp = (taskNode*)malloc(1*sizeof(taskNode));
        temp->task = *data;
        temp->ptr = stack->front; 
        stack->front = temp;  
    }
}
 
/*popTask()-  removes and returns the first element from the stack */
tasks popTask(taskStack* stack){
    taskNode *front1 = stack->front;
    tasks returnTask; 
    if (front1 == NULL){
        printf("\n Error: Trying to pop elements from empty stack");
        return returnTask; 
    }
    else{
        if (front1->ptr != NULL){
            returnTask = stack->front->task; 
            front1 = front1->ptr;
            free(stack->front);
            stack->front = front1;
            return returnTask;
        }
        else{
            returnTask = stack->front->task; 
            free(stack->front);
            stack->front = NULL;
            stack->rear = NULL;
            return returnTask;
        }
    }
}

/* empty()-  shows if stack is empty or not */
int emptyTask(taskStack* stack){
     if ((stack->front == NULL)){
        return 0; 
    }
    else{
       return 1; 
    }
}

 /*display() -  takes in the stack as a parameter and then displays the stack elements */
void displayT(taskStack* stack){
   //iterator variable assignment 
   taskNode* front1 = stack->front;

    if ((front1 == NULL) && (stack->rear == NULL)){
        printf("Task Stack is empty\n");
        return;
    }     
    while (front1 != stack->rear){
        printf("%s, %s, %i \n", front1->task.taskID, front1->task.taskSpec, front1->task.cycleNum);
        front1 = front1->ptr;
    }
    if (front1 == stack->rear){
      printf("%s, %s, %i \n", front1->task.taskID, front1->task.taskSpec, front1->task.cycleNum);
    }
}
